#include "GameOverSound.h"


void LoadGameOverSounds(void)
{
	LoadPlayerDeathSounds();
}

void CleanupGameOverSound(void)
{
	CleanupPlayerDeathSound();

}

