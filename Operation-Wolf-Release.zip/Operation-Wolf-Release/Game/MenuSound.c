#include "MenuSound.h"


void LoadMenuSounds(void)
{
	LoadButtonSounds();
}

void CleanupMenuSound(void)
{
	CleanupButtonSounds();
}

